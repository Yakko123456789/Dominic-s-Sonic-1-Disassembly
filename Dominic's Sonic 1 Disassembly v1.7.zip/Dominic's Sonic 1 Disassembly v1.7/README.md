This is Dominic's Sonic 1 Disassembly, this contains all the tools you need and want without searching for them, this is not based off of the latest disassembly of Sonic 1, if you want that one, go here: https://github.com/sonicretro/s1disasm

If you want, you can also import the tools from this disassembly to the latest one.